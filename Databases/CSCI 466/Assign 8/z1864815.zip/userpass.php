<?php
$servername = "courses";
$username = "z1864815";
$password = "2001Jan25";
$dbname = "z1864815";
?>
