//
//  MortgageLoanCalcApp.swift
//  MortgageLoanCalc
//
//  Created by Reinaldo Moraga on 3/30/22.
//

import SwiftUI

@main
struct MortgageLoanCalcApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
