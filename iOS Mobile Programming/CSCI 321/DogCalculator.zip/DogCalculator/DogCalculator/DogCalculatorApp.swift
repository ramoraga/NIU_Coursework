//
//  DogCalculatorApp.swift
//  DogCalculator
//
//  Created by Reinaldo Moraga & Rami Lake on 3/1/22.
//

import SwiftUI

@main
struct DogCalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
