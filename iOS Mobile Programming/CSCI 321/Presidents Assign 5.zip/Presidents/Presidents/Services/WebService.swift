//
//  WebService.swift
//  Presidents
//
//  Created by Reinaldo Moraga on 4/21/22.
//

import Foundation

class WebService {
    
    func fetchPresidents(url: URL?) async throws -> [President] {
        
        guard let url = url else {
            return []
        }
        
        let (data, _) = try await URLSession.shared.data(from: url)
        
        let presidents = try? JSONDecoder().decode([President].self, from: data)
        
        return presidents ?? []
    }
}
