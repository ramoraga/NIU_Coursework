//
//  Constants.swift
//  Presidents
//
//  Created by Reinaldo Moraga on 4/21/22.
//

import Foundation

struct Constants {
    
    struct Urls {
        
        static let presidentsUrl: URL? = URL(string: "https://www.prismnet.com/~mcmahon/CS321/presidents.json")
    }
}
