//
//  ContentView.swift
//  Presidents
//
//  Created by Rami Lake on 4/7/22.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject private var presidentListViewModel: PresidentListViewModel

    init() {
        _presidentListViewModel = StateObject(wrappedValue: PresidentListViewModel())
    }
        
    var body: some View {
        NavigationView {
            List {
                ForEach(presidentListViewModel.presidents, id:\.number) {
                    presidentVM in

                    NavigationLink(destination: DetailViewController(president: presidentVM)) { PresidentCell(president: presidentVM)
                    }
                }
            }
            .listStyle(.plain)
            .task { // this is on appear when calling remote data?
                await
                presidentListViewModel.getPresidents()
                //presidentListViewModel.loadPropertyListData()
            }
            .navigationTitle("Presidents")
            .navigationBarTitleDisplayMode(.inline)
        }
        .navigationViewStyle(.stack)
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
