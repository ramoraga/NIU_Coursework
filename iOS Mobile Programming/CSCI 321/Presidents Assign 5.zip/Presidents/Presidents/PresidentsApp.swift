//
//  PresidentsApp.swift
//  Presidents
//
//  Created by Rami Lake on 4/7/22.
//

import SwiftUI

@main
struct PresidentsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
