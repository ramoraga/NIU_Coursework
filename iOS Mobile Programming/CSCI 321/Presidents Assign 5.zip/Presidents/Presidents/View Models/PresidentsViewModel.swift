//
//  PresidentsViewModel.swift
//  Presidents
//
//  Created by Rami Lake on 4/7/22.
//

import Foundation

@MainActor
class PresidentListViewModel: ObservableObject {
    
    @Published var presidents: [PresidentViewModel] = []
    
   /* func loadPropertyListData() {
        guard let path = Bundle.main.path(forResource: "presidents", ofType: ".plist"), let xml = FileManager.default.contents(atPath: path) else {
            fatalError("Cannot access the property list called, presidents.plist. Please try again!")
        }
       
        do {
            var presidents = try PropertyListDecoder().decode([President].self, from: xml)
            
            presidents.sort {
                $0.number < $1.number
            }
            
            self.presidents = presidents.map(PresidentViewModel.init)
            
            
        } catch {
            fatalError("Can't decode the preperty list, presidents.plist.")
        }
    }
}*/
    
        func getPresidents() async {
            
            do {
                var presidents = try await WebService().fetchPresidents(url: Constants.Urls.presidentsUrl)
                presidents.sort {
                    $0.number < $1.number
                }
                self.presidents = presidents.map(PresidentViewModel.init)
            } catch {
                print(error)
            }
            
        }
    }



struct PresidentViewModel {
    var president: President


    var name: String {
        return president.name
    }

    var number: Int {
        return president.number
    }

    var startDate: String {
        return president.startDate
    }

    var endDate: String {
        return president.endDate
    }

    var nickName: String {
        return president.nickName
    }

    var politicalParty: String {
        return president.politicalParty
    }
    
    var url: String {
        return president.url
    }


    static var `default`: PresidentViewModel {
        let president = President(name: "George Washington", number: 1, startDate: "Startdate", endDate: "EndDate", nickName: "Georgy", politicalParty: "Founder", url: "https://www.potus.com/wp-content/uploads/2018/08/01_george_washington_1_gallery.jpg")

        return PresidentViewModel(president: president)
    }

}
