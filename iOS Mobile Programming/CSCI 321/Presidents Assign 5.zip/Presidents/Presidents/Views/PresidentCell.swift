//
//  PresidentCell.swift
//  Presidents
//
//  Created by Rami Lake on 4/7/22.
//

import SwiftUI

struct PresidentCell: View {
    
    var president: PresidentViewModel
    
    var body: some View {

        HStack {
            AsyncImage(url: URL(string: president.url)) {
                image in
                image.resizable()
                    .cornerRadius(8)
            } placeholder: {
                ProgressView()
            }
            .frame(width: 60, height: 90)
            
            VStack (alignment: .leading){
                Text(president.name)
                    .font(.headline)
                    .fontWeight(.heavy)
                Text(president.politicalParty)
                    .font(.subheadline)
            }
        }
    }
}

struct PresidentCell_Previews: PreviewProvider {
    static var previews: some View {
        PresidentCell(president: PresidentViewModel.default)
            .previewLayout(.sizeThatFits)
    }
}

