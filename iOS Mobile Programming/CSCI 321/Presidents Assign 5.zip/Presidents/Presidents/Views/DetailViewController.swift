//
//  DetailViewController.swift
//  Presidents
//
//  Created by Rami Lake on 4/7/22.
//

import SwiftUI

var numberFormatter: NumberFormatter {
    let formatter = NumberFormatter()
    formatter.numberStyle = .ordinal
    return formatter
}

struct DetailViewController: View {
    
    var president: PresidentViewModel
    
    var body: some View {
        VStack (spacing: 0) {
                        
            Text(president.name)
                .font(.title)
                .bold()
                .multilineTextAlignment(.center)
                //.frame(maxWidth: 400, maxHeight: .infinity)
            
            Text("\(numberFormatter.string(from: NSNumber(value: president.number))!) President of the United States")
                .font(.headline)
                .bold()
                .padding(8)
            
            Text("(\(president.startDate) to \(president.endDate))")
                .font(.headline)
                .fontWeight(.regular)
                .italic()
            
            AsyncImage(url: URL(string: president.url)) {
                image in
                image.resizable()
                    .scaledToFit()
                    .cornerRadius(16)
            } placeholder: {
                ProgressView()
            }
            .padding(8)
            
            
            Text("Nickname")
                .bold()
                .font(.headline)
            
            Text("\(president.nickName)")
                .padding(7)
                .fixedSize(horizontal: false, vertical: true)
                .multilineTextAlignment(.center)
            
            Text("Political Party")
                .bold()
                .font(.headline)
            
            Text(president.politicalParty)
                .padding(7)
            
            Spacer()
        }
    }
}

struct DetailViewController_Previews: PreviewProvider {
    static var previews: some View {
        DetailViewController(president: PresidentViewModel.default)
    }
}
