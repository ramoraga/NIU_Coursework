//
//  Master View Controller.swift
//  Presidents
//
//  Created by Rami Lake on 4/7/22.
//

import SwiftUI

struct Master_View_Controller: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Master_View_Controller_Previews: PreviewProvider {
    static var previews: some View {
        Master_View_Controller()
    }
}
