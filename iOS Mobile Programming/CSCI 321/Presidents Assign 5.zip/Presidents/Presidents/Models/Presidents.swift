//
//  Presidents.swift
//  Presidents
//
//  Created by Rami Lake on 4/7/22.
//

import Foundation


struct President: Decodable {
    var name: String = ""
    var number: Int = 0
    var startDate: String = ""
    var endDate: String = ""
    var nickName: String = ""
    var politicalParty: String = ""
    var url = ""
    
    private enum CodingKeys: String, CodingKey {
        case name = "Name"
        case number = "Number"
        case startDate = "Start Date"
        case endDate = "End Date"
        case nickName = "Nickname"
        case politicalParty = "Political Party"
        case url = "URL"
    }
    
    init(name: String, number: Int, startDate: String, endDate: String, nickName: String, politicalParty: String, url: String)
    {
        self.name = name
        self.number = number
        self.startDate = startDate
        self.endDate = endDate
        self.nickName = nickName
        self.politicalParty = politicalParty
        self.url = url
    }
}
